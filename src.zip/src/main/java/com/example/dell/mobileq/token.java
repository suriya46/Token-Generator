package com.example.dell.mobileq;

public class token {
    public  String token;

    public token()
    {

    }

    public  String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public token(String token) {
        this.token = token;
    }
}
